package com.example.quiz;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class QuizHelper extends SQLiteOpenHelper {
    private Context context;
    private static final String DB_NAME = "TQuiz.db";

    private static final int DB_VERSION = 3;

    private static final String TABLE_NAME = "TQ";

    private static final String UID = "_UID";

    private static final String QUESTION = "QUESTION";

    private static final String OPTA = "OPTA";

    private static final String OPTB = "OPTB";

    private static final String OPTC = "OPTC";

    private static final String OPTD = "OPTD";

    private static final String ANSWER = "ANSWER";
     private static final String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " ( " + UID + " INTEGER PRIMARY KEY AUTOINCREMENT , " + QUESTION + " VARCHAR(255), " + OPTA + " VARCHAR(255), " + OPTB + " VARCHAR(255), " + OPTC + " VARCHAR(255), " + OPTD + " VARCHAR(255), " + ANSWER + " VARCHAR(255));";

    private static final String DROP_TABLE = "DROP TABLE IF EXISTS " + TABLE_NAME;

    QuizHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        //OnCreate csak egyszer történik
        sqLiteDatabase.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
     // akkor hivodik meg ha frissitjuk az adatbázist
      sqLiteDatabase.execSQL(DROP_TABLE);
        onCreate(sqLiteDatabase);
    }

    void allQuestion() {
        ArrayList<Question> arraylist = new ArrayList<>();

        arraylist.add(new Question("The oldest brewing company in the U.S. is?", "Anheuser-Busch.", "Yuengling", "Coors", "Sam Adams", "Yuengling"));

        arraylist.add(new Question("Munich declared Oktoberfest an official celebration in ?", "1710", "1810", "1910", "2010", "1810"));

        arraylist.add(new Question("Which brewer is largely credited with inventing the strain of yeast used in many of today’s lagers?", "Heineken", "Budweiser Budvar", "Carlsberg", "Beck’s", "Carlsberg"));

        arraylist.add(new Question("How many calories does a typical pint of 5% lager contain?", "185", "200", "215", "285", "215"));

        arraylist.add(new Question("Which beer brand recently changed its recipe to better replicate how it tastes in its home country?", "Guinness", "Asahi", "Newcastle Brown Ale", "Stella Artois 8", "Asahi"));

        arraylist.add(new Question("Who is the world’s biggest brewer?", "Anheuser-Busch InBev", "China Resource Snow Brewery", "SAB Miller", "Heineken", "Anheuser-Busch InBev"));

        arraylist.add(new Question("What is the world’s biggest beer brand?", "Bud Light", "Budweiser", "Snow", "Tsingtao", "Snow"));

        arraylist.add(new Question("Which is the largest hop-producing country in the world?", "China", "Germany", "US", "Czech Republic", "Germany"));

        arraylist.add(new Question("When is Germany’s famous strong beer festival?", "September", "October", "June", "March 24", "March 24"));

        arraylist.add(new Question("What is the oldest beer brand still being produced today?", "Augustiner", "Weihenstephan", "Chimay", "Duvel", "Weihenstephan"));

        arraylist.add(new Question("What is the science of brewing beer called?", " Zorology", "Zymurgy", "Zumology", "Zoophagy", "Zymurgy"));

        arraylist.add(new Question("What city in the United States has had the most breweries?", " Chicago, IL", " New York, NY", " Philadelphia, PA", " Philadelphia, PA", " Philadelphia, PA"));

        arraylist.add(new Question("The top five nations that brew beer are USA, China, Germany, Japan and what other country?", "England", "Spain", "Ireland", "Brazil", "Brazil"));

        arraylist.add(new Question("What ancient people is credited with first having brewed beer?", "Chinese", "Greeks", "Mayans", "Babylonian", "Babylonian"));





        this.addAllQuestions(arraylist);

    }


    private void addAllQuestions(ArrayList<Question> allQuestions) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues values = new ContentValues();
            for (Question question : allQuestions) {
                values.put(QUESTION, question.getQuestion());
                values.put(OPTA, question.getOptA());
                values.put(OPTB, question.getOptB());
                values.put(OPTC, question.getOptC());
                values.put(OPTD, question.getOptD());
                values.put(ANSWER, question.getAnswer());
                db.insert(TABLE_NAME, null, values);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
            db.close();
        }
    }


    List<Question> getAllOfTheQuestions() {

        List<Question> questionsList = new ArrayList<>();
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();
        String coloumn[] = {UID, QUESTION, OPTA, OPTB, OPTC, OPTD, ANSWER};
        Cursor cursor = db.query(TABLE_NAME, coloumn, null, null, null, null, null);


        while (cursor.moveToNext()) {
            Question question = new Question();
            question.setId(cursor.getInt(0));
            question.setQuestion(cursor.getString(1));
            question.setOptA(cursor.getString(2));
            question.setOptB(cursor.getString(3));
            question.setOptC(cursor.getString(4));
            question.setOptD(cursor.getString(5));
            question.setAnswer(cursor.getString(6));
            questionsList.add(question);
        }

        db.setTransactionSuccessful();
        db.endTransaction();
        cursor.close();
        db.close();
        return questionsList;
    }
}
