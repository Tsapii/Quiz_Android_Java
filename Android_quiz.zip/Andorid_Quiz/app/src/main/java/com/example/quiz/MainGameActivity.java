package com.example.quiz;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.Collections;
import java.util.List;

import info.hoang8f.widget.FButton;

public class MainGameActivity extends AppCompatActivity {
    FButton buttonA, buttonB, buttonC, buttonD;
    TextView questionText, QuizText, timeText, resultText, beerText;
    QuizHelper QuizHelper;
    Question currentQuestion;
    List<Question> list;
    int qid = 0;
    int timeValue = 20;
    int beerValue = 0;
    CountDownTimer countDownTimer;
    Typeface tb, sb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_main);

        //A változók inicializálása
        questionText = (TextView) findViewById(R.id.Question);
        buttonA = (FButton) findViewById(R.id.buttonA);
        buttonB = (FButton) findViewById(R.id.buttonB);
        buttonC = (FButton) findViewById(R.id.buttonC);
        buttonD = (FButton) findViewById(R.id.buttonD);
        QuizText = (TextView) findViewById(R.id.QuizText);
        timeText = (TextView) findViewById(R.id.timeText);
        resultText = (TextView) findViewById(R.id.resultText);
        beerText = (TextView) findViewById(R.id.coinText);

        // Betűtípusok a Textview és Buttonshez
        tb = Typeface.createFromAsset(getAssets(), "fonts/TitilliumWeb-Bold.ttf");
        sb = Typeface.createFromAsset(getAssets(), "fonts/shablagooital.ttf");
        QuizText.setTypeface(sb);
        questionText.setTypeface(tb);
        buttonA.setTypeface(tb);
        buttonB.setTypeface(tb);
        buttonC.setTypeface(tb);
        buttonD.setTypeface(tb);
        timeText.setTypeface(tb);
        resultText.setTypeface(sb);
        beerText.setTypeface(tb);

        //Adatbázis osztálya
        QuizHelper = new QuizHelper(this);
        // Írható adatbázis
        QuizHelper.getWritableDatabase();

        //Ellenőrzi, hogy a kérdések, opciók már szerepelnek-e a táblázatban, vagy sem

        //Ha nem adjuk hozzá őket, akkor a getAllOfTheQuestions () visszaadja a nulla méretű listát
        if (QuizHelper.getAllOfTheQuestions().size() == 0) {

            QuizHelper.allQuestion();
        }

        //Ez visszaadja nekünk a aQuestion adattípus listáját
        list = QuizHelper.getAllOfTheQuestions();

        //  Felkeverjük a lista elemeit, hogy véletlenszerűen kapjunk kérdéseket
        Collections.shuffle(list);

        //currentQuestion 4 válasz lehetőséget és a kérdesét és a választ fogja egy id-hez rendelni.

        currentQuestion = list.get(qid);

        //visszaszámláló
        countDownTimer = new CountDownTimer(22000, 1000) {
            public void onTick(long millisUntilFinished) {

                //Timetext-et állitombe
                timeText.setText(String.valueOf(timeValue) + "\"");


                //Minden iterációval csökken az idő 1 másodperccel
                timeValue -= 1;


                //Ez azt jelenti, hogy a felhasználó kifutott az időből, így az onFinished meghivja ezt az iterációt
                if (timeValue == -1) {

                    //Közel van az 1 sechez felugrik a TimeUP
                    resultText.setText(getString(R.string.timeup));

                    //Mivel a felhasználó elkésett nem tud kattintani egyetlen gombra sem

                    disableButton();
                }
            }

            //Felhasználó kifutott az időből
            public void onFinish() {
                timeUp();
            }
        }.start();

        //Ez a  beállítja a kérdést és a négy válasz lehetőséget
        updateQueAndOptions();


    }


    public void updateQueAndOptions() {

        //Ez a method beállítja a setText-et a kérdés és az opciók számára
        questionText.setText(currentQuestion.getQuestion());
        buttonA.setText(currentQuestion.getOptA());
        buttonB.setText(currentQuestion.getOptB());
        buttonC.setText(currentQuestion.getOptC());
        buttonD.setText(currentQuestion.getOptD());


        timeValue = 20;

        //Most, hogy a felhasználó helyesen válaszolt resetelem a time-ert egy másik kérdeshez
        countDownTimer.cancel();
        countDownTimer.start();


        //beállitom be az érmeszöveg értékét
        beerText.setText(String.valueOf(beerValue));
        //A felhasználó  növeli az sörök számát
        beerValue++;

    }


    public void buttonA(View view) {
        // Össze hasonlitja az opciot a válasszal ha egyeezik akkor  a gombot zöldre állitja
        if (currentQuestion.getOptA().equals(currentQuestion.getAnswer())) {
            buttonA.setButtonColor(ContextCompat.getColor(getApplicationContext(),R.color.green));

            // Ellenőrizze, hogy a felhasználó nem haladja-e meg a sorhatárt
            if (qid < list.size() - 1) {

                // Ha a felhasználó helyesen válaszol akkor a tobbi gomb le van tiltva. Megnyom egy gombot akkot a többi is le lesz tiltva
                disableButton();

                //Feljön a correct dialog
                correctDialog();
            }
            //Ha a felhasználó az összes kérdésre válaszolt akkor gamewon activity meghivja
            else {

                gameWon();

            }
        }
        //Ha a felhasználó az rosszul válaszolt a  kérdésre akkor playagain activity hivodik meg
        else {

            gameLostPlayAgain();

        }
    }


    public void buttonB(View view) {
        if (currentQuestion.getOptB().equals(currentQuestion.getAnswer())) {
            buttonB.setButtonColor(ContextCompat.getColor(getApplicationContext(),R.color.green));
            if (qid < list.size() - 1) {
                disableButton();
                correctDialog();
            } else {
                gameWon();
            }
        } else {
            gameLostPlayAgain();
        }
    }


    public void buttonC(View view) {
        if (currentQuestion.getOptC().equals(currentQuestion.getAnswer())) {
            buttonC.setButtonColor(ContextCompat.getColor(getApplicationContext(),R.color.green));
            if (qid < list.size() - 1) {
                disableButton();
                correctDialog();
            } else {
                gameWon();
            }
        } else {

            gameLostPlayAgain();
        }
    }

    public void buttonD(View view) {
        if (currentQuestion.getOptD().equals(currentQuestion.getAnswer())) {
            buttonD.setButtonColor(ContextCompat.getColor(getApplicationContext(),R.color.green));
            if (qid < list.size() - 1) {
                disableButton();
                correctDialog();
            } else {
                gameWon();
            }
        } else {
            gameLostPlayAgain();
        }
    }

    //Jelenlegi helyzetből  a gameWon ugrik
    public void gameWon() {
        Intent intent = new Intent(this, GameWon.class);
        startActivity(intent);
        finish();
    }

    //Ez akkor hivodik meg ha rosszul válaszolt a kérdesre
    //Jelenlegi helyzetből  a PlayAgain ugrik
    public void gameLostPlayAgain() {
        Intent intent = new Intent(this, PlayAgain.class);
        startActivity(intent);
        finish();
    }

    //Ez akkor hivodik meg ha az idő lejár
    public void timeUp() {
        Intent intent = new Intent(this, Time_Up.class);
        startActivity(intent);
        finish();
    }

    //Ha a felhasználó megnyomja a home gombot, akkor memóriából jön a quiz vissza
    //Metódus folytatja az időzítőt az  ahonna abbahagytuk
    @Override
    protected void onRestart() {
        super.onRestart();
        countDownTimer.start();
    }


    // folytatja az időzítőt az  ahonna abbahagytuk
    @Override
    protected void onStop() {
        super.onStop();
        countDownTimer.cancel();
    }

    //Megállitja a timert
    @Override
    protected void onPause() {
        super.onPause();
        countDownTimer.cancel();
    }


    @Override
    public void onBackPressed() {
        Intent intent = new Intent(this, HomeScreen.class);
        startActivity(intent);
        finish();
    }

    // Ha felhasználó helyesen válaszol felugrik ez a dialog
    public void correctDialog() {
        final Dialog dialogCorrect = new Dialog(MainGameActivity.this);
        dialogCorrect.requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (dialogCorrect.getWindow() != null) {
            ColorDrawable colorDrawable = new ColorDrawable(Color.TRANSPARENT);
            dialogCorrect.getWindow().setBackgroundDrawable(colorDrawable);
        }
        dialogCorrect.setContentView(R.layout.dialog_correct);
        dialogCorrect.setCancelable(false);
        dialogCorrect.show();

        //Mivel felugrik a dialog a hátterben az ora megáll
        onPause();


        TextView correctText = (TextView) dialogCorrect.findViewById(R.id.correctText);
        FButton buttonNext = (FButton) dialogCorrect.findViewById(R.id.dialogNext);

        //Beéllitja a betutipusokat
        correctText.setTypeface(sb);
        buttonNext.setTypeface(sb);

        //OnCLick kovetkezo kérdeesre
        buttonNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Vége a dialognak
                dialogCorrect.dismiss();
                //Növeli a kérdés számot
                qid++;
                //lekéri a kérdeést,opciokat es a választ
                currentQuestion = list.get(qid);
                //Beállitja a 4 uj választ és a kérdést
                updateQueAndOptions();
                //Visszaállitja a gombok szinet.
                resetColor();
                enableButton();
            }
        });
    }

//Ez a Method: a gomb ismét fehér színűvé válik, mivel az egyik gomb színünk zöld lett
   public void resetColor() {
        buttonA.setButtonColor(ContextCompat.getColor(getApplicationContext(),R.color.white));
        buttonB.setButtonColor(ContextCompat.getColor(getApplicationContext(),R.color.white));
        buttonC.setButtonColor(ContextCompat.getColor(getApplicationContext(),R.color.white));
        buttonD.setButtonColor(ContextCompat.getColor(getApplicationContext(),R.color.white));
    }


    // Ez a Method letiltja az összes opciógombot
    public void disableButton() {
        buttonA.setEnabled(false);
        buttonB.setEnabled(false);
        buttonC.setEnabled(false);
        buttonD.setEnabled(false);
    }


    // Ez a Method engedélyezi az opciógombokat
    public void enableButton() {
        buttonA.setEnabled(true);
        buttonB.setEnabled(true);
        buttonC.setEnabled(true);
        buttonD.setEnabled(true);
    }
}
